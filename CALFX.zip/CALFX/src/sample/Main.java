package sample;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javax.script.*;

// 拖动监听器
class DragListener implements EventHandler<MouseEvent> {
    private double xOffset = 0;
    private double yOffset = 0;
    private final Stage stage;
    public DragListener(Stage stage) {
        this.stage = stage;
    }
    @Override
    public void handle(MouseEvent event) {
        event.consume();
        if (event.getEventType() == MouseEvent.MOUSE_PRESSED) {
            xOffset = event.getSceneX();
            yOffset = event.getSceneY();
        } else if (event.getEventType() == MouseEvent.MOUSE_DRAGGED) {
            stage.setX(event.getScreenX() - xOffset);
            if(event.getScreenY() - yOffset < 0) {
                stage.setY(0);
            }else {
                stage.setY(event.getScreenY() - yOffset);
            }
        }
    }
    public void enableDrag(Node node) {
        node.setOnMousePressed(this);
        node.setOnMouseDragged(this);
    }
}
class DragUtil {
    public static void addDragListener(Stage stage,Node root) {
        new DragListener(stage).enableDrag(root);
    }
}

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("CalViewbj.fxml"));
        primaryStage.setTitle("科学计算器");
        primaryStage.setMinHeight(700);
        primaryStage.setMinWidth(400);
        primaryStage.initStyle(StageStyle.TRANSPARENT);
        Scene scene = new Scene(root, 540, 800 , Color.TRANSPARENT);
        scene.getStylesheets().add("skin.css");
        scene.setFill(null);
        primaryStage.setScene(scene);
        // 拖动监听器
        DragUtil.addDragListener(primaryStage, root);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
