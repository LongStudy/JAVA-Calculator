package sample;

import javax.script.*;
import java.util.Stack;


public class CalEP {
    public static boolean isValid(String s) {
        //判断（）是否对其
        Stack<Character> stack = new Stack<>();   //创建一个栈
        for (int i = 0; i < s.length(); i++) {
            if ((s.charAt(i) == '(') || (s.charAt(i) == '[') || (s.charAt(i) == '{')) {    // 如果是左括号，则将其放入栈内
                stack.push(s.charAt(i));
            } else if ((s.charAt(i) == ')') || (s.charAt(i) == ']') || (s.charAt(i) == '}')) {   // 如果是右括号
                if (stack.empty()) {     //  如果栈为空，则证明括号不匹配，返回false
                    return false;
                }if ((stack.peek() == '(' && s.charAt(i) == ')') || (stack.peek() == '[' && s.charAt(i) == ']') || (stack.peek() == '{' && s.charAt(i) == '}') ) {     // 如果栈顶元素和下一个右括号相匹配，则将其栈顶元素出栈
                    stack.pop();
                }
            }
        }// 遍历循环结束后，如果发现栈里为空，则证明括号匹配完毕；否则括号不匹配
        return stack.empty();
    }

    public String replaceString(String input){
        //取余%与四则运算原生方法
        input = input.replace(" ","");
        //原生符号
        input = input.replaceAll("pi|PI|Pi|pI|π","Math.PI");
        input = input.replace("LN2","Math.LN2");
        input = input.replace("LN10","Math.LN10");
        input = input.replace("LOG2E","Math.LOG2E");
        input = input.replace("LOG10E","Math.LOG10E");
        input = input.replace("SQRT1_2","Math.SQRT1_2");
        input = input.replace("SQRT2","Math.SQRT2");
        //角度与弧度的实现
        input = input.replace("°","*(Math.PI/180)");
        //input = input.replaceAll("DEG(?=\\()","(180/Math.PI)*");
        //input = input.replaceAll("RAD(?=\\()","(Math.PI/180)*");
        //乘法补充
        input = input.replaceAll("\\)\\(",")*(");
        input = input.replaceAll("(?<![a-zA-z])(\\d+)(?=\\()","$1*");
        input = input.replaceAll("(?<![a-zA-z])(\\d+)(?=[a-zA-Z])","$1*");
        input = input.replace("LOG10*E","LOG10E");
        //原生三角函数
        input = input.replaceAll("(?<!a)sin(?=\\()","Math.sin");
        input = input.replaceAll("(?<!\\.)asin(?=\\()","Math.asin");
        input = input.replaceAll("(?<!a)cos(?=\\()","Math.cos");
        input = input.replaceAll("(?<!\\.)acos(?=\\()","Math.acos");
        input = input.replaceAll("(?<!a)tan(?=\\()","Math.tan");
        input = input.replaceAll("(?<!\\.)atan(?=\\()","Math.atan");
        input = input.replaceAll("(?<!\\.)atan2(?=\\()","Math.atan2");
        //扩充三角函数
        //input = input.replaceAll("(?<!\\.)sec\\(([^\\(]*)\\)","(1/Math.cos($1))");
        //input = input.replaceAll("(?<!\\.)csc\\(([^\\(]*)\\)","(1/Math.sin($1))");
        //input = input.replaceAll("(?<!\\.)cot\\(([^\\(]*)\\)","(1/Math.tan($1))");
        //原生取整
        input = input.replaceAll("(?<!\\.)ceil(?=\\()","Math.ceil");
        input = input.replaceAll("(?<!\\.)floor(?=\\()","Math.floor");
        input = input.replaceAll("(?<!\\.)round(?=\\()","Math.round");
        input = input.replaceAll("(?<!\\.)random(?=\\()","Math.random");
        //e相关
        input = input.replaceAll("(?<!\\.)e\\^((\\d+(\\.\\d+)?)|([+-]?(\\d+(\\.\\d+)?)))","Math.exp($1)");
        input = input.replaceAll("(?<!\\.)e\\^(?=\\()","Math.exp");
        input = input.replaceAll("(?<!\\.|s|D|c|n)e(?!\\^)","Math.E");
        //任意指数实现
        input = input.replaceAll("(\\d+)\\^\\(([^\\(]*)\\)","pow($1,$2)");
        input = input.replaceAll("\\(([^\\(]*)(?=\\)\\^)","pow($1");
        input = input.replaceAll("\\)\\^\\(",",");
        input = input.replaceAll("\\)\\[",",");
        input = input.replaceAll("\\](?!\\()",")");
        //开方
        input = input.replaceAll("(?!\\.)sqrt(?=\\()","Math.sqrt");
        //input = input.replaceAll("(?!\\.)cbrt\\(([^\\(]*)\\)","Math.pow($1,1/3)");
        //input = input.replaceAll("(?!\\.)root\\[([^\\[]*)\\]\\(([^\\(]*)\\)","Math.pow($2,1/($1))");
        //对数实现
        input = input.replaceAll("(?!\\.)ln(?=\\()","Math.log");
        //input = input.replaceAll("(?!\\.)log\\[([^\\[]*)\\]\\(([^\\(]*)\\)","(Math.log($2)/Math.log($1))");
        //比较与绝对值
        input = input.replaceAll("(?!\\.)max(?=\\()","Math.max");
        input = input.replaceAll("(?!\\.)min(?=\\()","Math.min");
        input = input.replaceAll("(?!\\.)abs(?=\\()","Math.abs");
        //！与（）！阶乘实现
        input = input.replaceAll("\\(([^\\(]*)\\)!","factorial($1)");
        input = input.replaceAll("(\\d+)!","factorial($1)");
        //对数与指数修改解析
        input = input.replaceAll("(?<!\\))\\[","(");
        input = input.replaceAll("\\]\\(",",");
        //返回解析后的
        return input;
    }


    public static String Calequ(ScriptEngineManager scriptEM, String expression) {
        //String expression = "DEG(3.2sin(1°))+4(4+5)+2^3+root[4](16)+cos(log[2](16))+4!+cbrt(e^4)";
        //if(calString.isValid(expression)){System.out.println("yes");}
        //expression = calString.replaceString(expression);
        ScriptEngine scriptEg = scriptEM.getEngineByName("javascript");
        try {
            String.valueOf(scriptEg.eval("function factorial(num){if(num <= 1) {return 1;}else{return num * factorial(num-1);}};\n" +
                    "function DEG(num) {return  (180/Math.PI)*num;};\n" +
                    "function RAD(num) {return  (Math.PI/180)*num;};\n" +
                    "function sec(num) {return  (1/Math.cos(num));};\n" +
                    "function csc(num) {return  (1/Math.sin(num));};\n" +
                    "function cot(num) {return  (1/Math.tan(num));};\n" +
                    "function cbrt(num) {return  Math.pow(num,1/3);};\n" +
                    "function root(num1,num2) {return  Math.pow(num2,1/(num1));};\n" +
                    "function pow(num1,num2) {return  Math.pow(num1,num2);};\n" +
                    "function lg(num) {return  (Math.log(num)/Math.log(10));};\n" +
                    "function neg(num) {return  -num;};\n" +
                    "function log(num1,num2) {return  (Math.log(num2)/Math.log(num1));};"));
            System.out.println(expression);
            String result = String.valueOf(scriptEg.eval(expression));
            if(result.contains("-Infinity")) {
                result=result+",-∞";
            }else if(result.contains("Infinity")) {
                result=result+",∞";
            }/*else if(result.contains("E")){
                String ytmp = result.substring(result.indexOf("E")+1);
                if((Integer.parseInt(ytmp))>15){
                    result = "∞ / NaN";
                }
            }*/
            return result;
        } catch (ScriptException e) {
            e.printStackTrace();
        }
        return "NaN";
    }
}