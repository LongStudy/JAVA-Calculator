package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.GridPane;

import javax.script.ScriptEngineManager;


public class CalView {

    @FXML
    private TextArea inputarea;

    @FXML
    private TextField outputarea;

    @FXML
    private MenuButton ang;

    @FXML
    private MenuItem a_sin;

    @FXML
    private MenuItem a_asin;

    @FXML
    private MenuItem a_cos;

    @FXML
    private MenuItem a_acos;

    @FXML
    private MenuItem a_tan;

    @FXML
    private MenuItem a_atan;

    @FXML
    private MenuItem a_sec;

    @FXML
    private MenuItem a_csc;

    @FXML
    private MenuItem a_cot;

    @FXML
    private MenuItem a_DEG;

    @FXML
    private MenuItem a_RAD;

    @FXML
    private MenuButton funm;

    @FXML
    private MenuItem f_abs;

    @FXML
    private MenuItem f_ceil;

    @FXML
    private MenuItem f_floor;

    @FXML
    private MenuItem f_round;

    @FXML
    private MenuItem f_random;

    @FXML
    private MenuItem f_max;

    @FXML
    private MenuItem f_min;

    @FXML
    private MenuButton con;

    @FXML
    private MenuItem con_e;

    @FXML
    private MenuItem con_pi;

    @FXML
    private MenuItem con_ln2;

    @FXML
    private MenuItem con_ln10;

    @FXML
    private MenuItem con_log2e;

    @FXML
    private MenuItem con_log10e;

    @FXML
    private MenuItem con_sqrt2;

    @FXML
    private MenuItem con_1_sqrt2;

    @FXML
    private Button sg_ang;

    @FXML
    private Button sg_ce;

    @FXML
    private Button sg_del;

    @FXML
    private Button sq2x;

    @FXML
    private Button powxn;

    @FXML
    private Button sg_l_mp;

    @FXML
    private Button sg_r_mp;

    @FXML
    private Button sg_fact;

    @FXML
    private Button sg_mod;

    @FXML
    private Button sq3x;

    @FXML
    private Button sg_pow;

    @FXML
    private Button sg_l_sp;

    @FXML
    private Button sg_r_sp;

    @FXML
    private Button sg_1divx;

    @FXML
    private Button sg_div;

    @FXML
    private Button sqyx;

    @FXML
    private Button powxy;

    @FXML
    private Button sg_7;

    @FXML
    private Button sg_8;

    @FXML
    private Button sg_9;

    @FXML
    private Button sg_mul;

    @FXML
    private Button pow2x;

    @FXML
    private Button lnx;

    @FXML
    private Button sg_4;

    @FXML
    private Button sg_5;

    @FXML
    private Button sg_6;

    @FXML
    private Button sg_sub;

    @FXML
    private Button pow10x;

    @FXML
    private Button lgx;

    @FXML
    private Button sg_1;

    @FXML
    private Button sg_2;

    @FXML
    private Button sg_3;

    @FXML
    private Button sg_plus;

    @FXML
    private Button powex;

    @FXML
    private Button logxy;

    @FXML
    private Button sg_neg;

    @FXML
    private Button sg_0;

    @FXML
    private Button sg_dot;

    @FXML
    private Button sg_equ;

    @FXML
    private GridPane key_7_6;

    @FXML
    void lgx_fun(ActionEvent event) {
        addString(inputarea,"lg()",1);
    }

    @FXML
    void lnx_fun(ActionEvent event) {
        addString(inputarea,"ln()",1);
    }

    @FXML
    void logxy_fun(ActionEvent event) {
        addString(inputarea,"log[]()",3);
    }

    @FXML
    void pow10x_fun(ActionEvent event) {
        addString(inputarea,"10^()",1);
    }

    @FXML
    void pow2x_fun(ActionEvent event) {
        addString(inputarea,"2^()",1);
    }

    @FXML
    void powex_fun(ActionEvent event) {
        addString(inputarea,"e^",0);
    }

    @FXML
    void powxn_fun(ActionEvent event) {
        addString(inputarea,"^()",1);
    }

    @FXML
    void powxy_fun(ActionEvent event) {
        addString(inputarea,"pow()[]",3);
    }

    @FXML
    public void sg_0_fun(ActionEvent event) {
        addString(inputarea,"0",0);
    }

    @FXML
    void sg_1_fun(ActionEvent event) {
        addString(inputarea,"1",0);
    }

    @FXML
    void sg_2_fun(ActionEvent event) {
        addString(inputarea,"2",0);
    }

    @FXML
    void sg_3_fun(ActionEvent event) {
        addString(inputarea,"3",0);
    }

    @FXML
    void sg_4_fun(ActionEvent event) {
        addString(inputarea,"4",0);
    }

    @FXML
    void sg_5_fun(ActionEvent event) {
        addString(inputarea,"5",0);
    }

    @FXML
    void sg_6_fun(ActionEvent event) {
        addString(inputarea,"6",0);
    }

    @FXML
    void sg_7_fun(ActionEvent event) {
        addString(inputarea,"7",0);
    }

    @FXML
    void sg_8_fun(ActionEvent event) {
        addString(inputarea,"8",0);
    }

    @FXML
    void sg_9_fun(ActionEvent event) {
        addString(inputarea,"9",0);
    }

    @FXML
    void sg_div_fun(ActionEvent event) {
        addString(inputarea,"/",0);
    }

    @FXML
    void sg_dot_fun(ActionEvent event) {
        addString(inputarea,".",0);
    }

    @FXML
    void sg_fact_fun(ActionEvent event) {
        addString(inputarea,"!",0);
    }

    @FXML
    void sg_l_mp_fun(ActionEvent event) {
        addString(inputarea,"[",0);
    }

    @FXML
    void sg_l_sp_fun(ActionEvent event) {
        addString(inputarea,"(",0);
    }

    @FXML
    void sg_mod_fun(ActionEvent event) {
        addString(inputarea,"%",0);
    }

    @FXML
    void sg_mul_fun(ActionEvent event) {
        addString(inputarea,"*",0);
    }

    @FXML
    void sg_plus_fun(ActionEvent event) {
        addString(inputarea,"+",0);
    }

    @FXML
    void sg_pow_fun(ActionEvent event) {
        addString(inputarea,"()^()",4);
    }

    @FXML
    void sg_r_mp_fun(ActionEvent event) {
        addString(inputarea,"]",0);
    }

    @FXML
    void sg_r_sp_fun(ActionEvent event) {
        addString(inputarea,")",0);
    }

    @FXML
    void sg_sub_fun(ActionEvent event) {
        addString(inputarea,"-",0);
    }

    @FXML
    void sq2x_fun(ActionEvent event) {
        addString(inputarea,"sqrt()",1);
    }

    @FXML
    void sq3x_fun(ActionEvent event) {
        addString(inputarea,"cbrt()",1);
    }

    @FXML
    void sqyx_fun(ActionEvent event) {
        addString(inputarea,"root[]()",3);
    }

    @FXML
    void sg_1divx_fun(ActionEvent actionEvent) {
        addString(inputarea,"1/",0);
    }

    public void addString(TextArea field, String addstr, int len) {
        int position = field.getCaretPosition();
        String text = field.getText();
        text = text.substring(0, position) + addstr + text.substring(position);
        field.setText(text);
        field.positionCaret(position+addstr.length()-len);
        field.requestFocus();
    }

    @FXML
    void sg_equ_fun(ActionEvent event) {
        CalEP cep2 = new CalEP();
        String txtfield =inputarea.getText();
        if(cep2.isValid(txtfield)){
            ScriptEngineManager scriptEM = new ScriptEngineManager();
            txtfield = cep2.replaceString(txtfield);
            txtfield = cep2.Calequ(scriptEM,txtfield);
            outputarea.setText(txtfield);
        }
        else{
            outputarea.setText("NaN / not aligned");
        }
    }

    @FXML
    void a_DEG_fun(ActionEvent event) {
        addString(inputarea,"DEG()",1);
    }

    @FXML
    void a_RAD_fun(ActionEvent event) {
        addString(inputarea,"RAD()",1);
    }

    @FXML
    void a_asin_fun(ActionEvent event) {
        addString(inputarea,"asin()",1);
    }

    @FXML
    void a_atan_fun(ActionEvent event) {
        addString(inputarea,"atan()",1);
    }

    @FXML
    void a_cos_fun(ActionEvent event) {
        addString(inputarea,"cos()",1);
    }

    @FXML
    void a_cot_fun(ActionEvent event) {
        addString(inputarea,"cot()",1);
    }

    @FXML
    void a_csc_fun(ActionEvent event) {
        addString(inputarea,"csc()",1);
    }

    @FXML
    void a_sec_fun(ActionEvent event) {
        addString(inputarea,"sec()",1);
    }

    @FXML
    void a_sin_fun(ActionEvent event) {
        addString(inputarea,"sin()",1);
    }

    @FXML
    void a_tan_fun(ActionEvent event) {
        addString(inputarea,"tan()",1);
    }

    @FXML
    void con_1_sqrt2_fun(ActionEvent event) {
        addString(inputarea,"SQRT1_2",0);
    }

    @FXML
    void con_e_fun(ActionEvent event) {
        addString(inputarea,"e",0);
    }

    @FXML
    void con_ln10_fun(ActionEvent event) {
        addString(inputarea,"LN10",0);
    }

    @FXML
    void con_ln2_fun(ActionEvent event) {
        addString(inputarea,"LN2",0);
    }

    @FXML
    void con_log10e_fun(ActionEvent event) {
        addString(inputarea,"LOG10E",0);
    }

    @FXML
    void con_log2e_fun(ActionEvent event) {
        addString(inputarea,"LOG2E",0);
    }

    @FXML
    void con_pi_fun(ActionEvent event) {
        addString(inputarea,"π",0);
    }

    @FXML
    void con_sqrt2_fun(ActionEvent event) {
        addString(inputarea,"SQRT2",0);
    }

    @FXML
    void f_abs_fun(ActionEvent event) {
        addString(inputarea,"abs()",1);
    }

    @FXML
    void f_ceil_fun(ActionEvent event) {
        addString(inputarea,"ceil()",1);
    }

    @FXML
    void f_floor_fun(ActionEvent event) {
        addString(inputarea,"floor()",1);
    }

    @FXML
    void f_max_fun(ActionEvent event) {
        addString(inputarea,"max(,)",2);
    }

    @FXML
    void f_min_fun(ActionEvent event) {
        addString(inputarea,"min(,)",2);
    }

    @FXML
    void f_random_fun(ActionEvent event) {
        addString(inputarea,"random()",1);
    }

    @FXML
    void f_round_fun(ActionEvent event) {
        addString(inputarea,"round()",1);
    }

    @FXML
    void sg_ang_fun(ActionEvent actionEvent) {
        addString(inputarea,"°",0);
    }

    @FXML
    void sg_ce_fun(ActionEvent actionEvent) {
        inputarea.setText("");
    }

    @FXML
    void sg_del_fun(ActionEvent actionEvent) {
        int position = inputarea.getCaretPosition();
        if(position>0){
            String text = inputarea.getText();
            text = text.substring(0, position-1) + text.substring(position);
            inputarea.setText(text);
            inputarea.positionCaret(position-1);
            inputarea.requestFocus();
        }
    }

    @FXML
    void sg_neg_fun(ActionEvent actionEvent) {
        addString(inputarea,"neg()",1);
    }

    @FXML
    void fun_gaussian_on(MouseEvent mouseEvent) {
        key_7_6.setEffect(new GaussianBlur());
    }
    @FXML
    void fun_gaussian_off(MouseEvent mouseEvent) {
        key_7_6.setEffect(new GaussianBlur(0));
    }
    @FXML
    void fun_close(ActionEvent actionEvent) {
        System.exit(0);
    }
}
