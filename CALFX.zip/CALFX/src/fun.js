
function factorial(num){if(num <= 1) {return 1;}else{return num * factorial(num-1);}};
function DEG(num) {return  (180/Math.PI)*num;};
function RAD(num) {return  (Math.PI/180)*num;};
function sec(num) {return  (1/Math.cos(num));};
function csc(num) {return  (1/Math.sin(num));};
function cot(num) {return  (1/Math.tan(num));};
function cbrt(num) {return  Math.pow(num,1/3);};
function root(num1,num2) {return  Math.pow(num2,1/(num1));};
function log(num1,num2) {return  (Math.log(num2)/Math.log(num1));};